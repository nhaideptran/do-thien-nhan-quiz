export type ThemeColorKey = 'blue' | 'pink' | 'purple' | 'emerald' | 'amber';

export interface ThemeConfig {
  id: ThemeColorKey;
  name: string;
  colorHex: string;
  badgeBg: string;
  gradientFrom: string;
  gradientTo: string;
  primaryBg: string;
  primaryHover: string;
  primaryText: string;
  borderActive: string;
  ringColor: string;
  accentBg: string;
}

export interface QuizOption {
  id: string;
  text: string;
}

export interface QuizQuestion {
  id: number;
  question: string;
  subtitle?: string;
  options: QuizOption[];
  correctOptionId: string;
  explanation: string;
  messiComment: string;
  tag: string;
  iconName: string;
}

export interface AvatarOption {
  id: string;
  emoji: string;
  name: string;
  badge: string;
  bgColor: string;
}

export interface QuizSubmission {
  id: string;
  playerName: string;
  isAnonymous: boolean;
  avatarId: string;
  score: number;
  totalQuestions: number;
  percentage: number;
  answers: Record<number, string>;
  submittedAt: number;
  timeSpentSeconds: number;
  feedbackTier: 'soulmate' | 'close_friend' | 'casual_friend' | 'stranger';
  feedbackTitle: string;
  feedbackQuote: string;
}

export type ViewMode = 'start' | 'quiz' | 'result' | 'dashboard';
