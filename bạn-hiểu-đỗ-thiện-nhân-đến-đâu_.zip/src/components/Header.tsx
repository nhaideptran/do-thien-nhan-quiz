import React, { useState, useRef, useEffect } from 'react';
import { useTheme } from '../context/ThemeContext';
import { ViewMode, ThemeColorKey } from '../types';
import { THEMES } from '../data/quizData';
import {
  Sun,
  Moon,
  Volume2,
  VolumeX,
  Palette,
  Sparkles,
  Home,
  LayoutGrid,
  Check,
  Menu,
  X,
  Heart,
} from 'lucide-react';
import { sound } from '../utils/sound';

interface HeaderProps {
  currentView: ViewMode;
  onNavigate: (view: ViewMode) => void;
  onOpenCreateModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onNavigate,
  onOpenCreateModal,
}) => {
  const { theme, themeKey, setThemeKey, isDark, toggleDarkMode, isMuted, toggleMute } = useTheme();
  const [isThemeMenuOpen, setIsThemeMenuOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const themeDropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (themeDropdownRef.current && !themeDropdownRef.current.contains(e.target as Node)) {
        setIsThemeMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleNavClick = (view: ViewMode) => {
    sound.playClick();
    onNavigate(view);
    setIsMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-white/90 dark:bg-slate-900/90 border-b border-slate-200/60 dark:border-slate-800 transition-colors duration-200">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Left: Cute Brand Wordmark as seen in screenshot */}
        <button
          onClick={() => handleNavClick('start')}
          className="flex items-center gap-2 text-left group focus-visible:outline-none rounded-xl shrink-0"
          aria-label="Về trang chủ"
        >
          <div className="w-8 h-8 rounded-full bg-pink-500 flex items-center justify-center text-white shadow-sm transition-transform duration-200 group-hover:scale-105">
            <Heart className="w-4 h-4 fill-white text-white" />
          </div>
          <span className="text-base sm:text-lg font-extrabold tracking-tight text-pink-500 hover:text-pink-600 transition-colors whitespace-nowrap">
            Bạn Hiểu Mình Đến Đâu?
          </span>
        </button>

        {/* Center / Right: Navigation & Actions */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Desktop Nav Links */}
          <nav className="hidden md:flex items-center gap-1.5 mr-1">
            <button
              onClick={() => handleNavClick('start')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm font-bold rounded-full transition-colors whitespace-nowrap ${
                currentView === 'start' || currentView === 'quiz'
                  ? 'text-violet-600 dark:text-violet-400 bg-violet-50 dark:bg-violet-950/40'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Home className="w-4 h-4 text-violet-500" />
              <span>Home</span>
            </button>

            <button
              onClick={() => handleNavClick('dashboard')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm font-bold rounded-full transition-colors whitespace-nowrap ${
                currentView === 'dashboard'
                  ? 'text-sky-600 dark:text-sky-400 bg-sky-50 dark:bg-sky-950/40'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <LayoutGrid className="w-4 h-4 text-sky-500" />
              <span>Dashboard</span>
            </button>
          </nav>

          {/* Theme Color Selector Pill */}
          <div className="relative" ref={themeDropdownRef}>
            <button
              onClick={() => {
                sound.playClick();
                setIsThemeMenuOpen(!isThemeMenuOpen);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-750 transition-colors shadow-2xs"
              title="Đổi màu giao diện"
              aria-label="Chọn màu chủ đề"
            >
              <span
                className="w-2.5 h-2.5 rounded-full ring-1 ring-black/10 shrink-0"
                style={{ backgroundColor: theme.colorHex }}
              />
              <span className="hidden sm:inline whitespace-nowrap">{theme.name}</span>
              <span className="text-[10px] text-slate-400">⌵</span>
            </button>

            {isThemeMenuOpen && (
              <div className="absolute right-0 mt-2 w-52 p-2 bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-700 z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-2 py-1 text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                  Chọn màu chủ đề
                </div>
                <div className="mt-1 space-y-1">
                  {(Object.keys(THEMES) as ThemeColorKey[]).map(key => {
                    const t = THEMES[key];
                    const isSelected = themeKey === key;
                    return (
                      <button
                        key={key}
                        onClick={() => {
                          setThemeKey(key);
                          setIsThemeMenuOpen(false);
                        }}
                        className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
                          isSelected
                            ? `${t.badgeBg} font-bold`
                            : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700/60'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span
                            className="w-3 h-3 rounded-full ring-1 ring-black/10"
                            style={{ backgroundColor: t.colorHex }}
                          />
                          <span>{t.name}</span>
                        </div>
                        {isSelected && <Check className="w-3.5 h-3.5" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Sound Mute Toggle */}
          <button
            onClick={toggleMute}
            className="p-1.5 rounded-full text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={isMuted ? 'Bật âm thanh' : 'Tắt âm thanh'}
            aria-label="Bật/tắt âm thanh"
          >
            {isMuted ? (
              <VolumeX className="w-4 h-4 text-slate-400" />
            ) : (
              <Volume2 className="w-4 h-4 text-slate-600 dark:text-slate-300" />
            )}
          </button>

          {/* Cute Yellow Sun / Moon Pill Toggle */}
          <button
            onClick={toggleDarkMode}
            className="flex items-center justify-center p-1.5 sm:px-2.5 sm:py-1 rounded-full border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold shadow-2xs hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
            title={isDark ? 'Chuyển sang giao diện Sáng' : 'Chuyển sang giao diện Tối'}
            aria-label="Chuyển chế độ sáng tối"
          >
            {isDark ? (
              <Moon className="w-4 h-4 text-indigo-400 hover:-rotate-12 transition-transform" />
            ) : (
              <div className="flex items-center gap-1">
                <span className="w-3.5 h-3.5 rounded-full bg-amber-400 ring-2 ring-amber-300/60" />
                <span className="text-[10px] text-slate-400 hidden sm:inline">⌵</span>
              </div>
            )}
          </button>

          {/* + Tạo Quiz Vibrant Pill Button (Matching Screenshot) */}
          <button
            onClick={() => {
              sound.playClick();
              onOpenCreateModal();
            }}
            className="flex items-center gap-1.5 px-4 py-1.5 text-xs sm:text-sm font-bold text-white rounded-full transition-transform active:scale-95 shadow-sm hover:shadow-md bg-gradient-to-r from-violet-600 via-fuchsia-500 to-pink-500 whitespace-nowrap"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Tạo Quiz</span>
          </button>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-1.5 rounded-full text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            aria-label="Mở menu"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {isMobileMenuOpen && (
        <div className="md:hidden px-4 pt-2 pb-4 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-2">
          <button
            onClick={() => handleNavClick('start')}
            className={`w-full flex items-center gap-2 px-3 py-2 text-xs sm:text-sm font-bold rounded-xl ${
              currentView === 'start'
                ? 'text-violet-600 bg-violet-50 dark:bg-violet-950/40'
                : 'text-slate-700 dark:text-slate-200'
            }`}
          >
            <Home className="w-4 h-4" />
            <span>Home</span>
          </button>

          <button
            onClick={() => handleNavClick('dashboard')}
            className={`w-full flex items-center gap-2 px-3 py-2 text-xs sm:text-sm font-bold rounded-xl ${
              currentView === 'dashboard'
                ? 'text-sky-600 bg-sky-50 dark:bg-sky-950/40'
                : 'text-slate-700 dark:text-slate-200'
            }`}
          >
            <LayoutGrid className="w-4 h-4" />
            <span>Dashboard</span>
          </button>
        </div>
      )}
    </header>
  );
};
