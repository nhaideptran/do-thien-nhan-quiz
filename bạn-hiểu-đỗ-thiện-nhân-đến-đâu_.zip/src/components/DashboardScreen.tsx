import React, { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { QuizSubmission, QuizQuestion } from '../types';
import { CUTE_AVATARS } from '../data/quizData';
import { sound } from '../utils/sound';
import {
  Trophy,
  Users,
  Award,
  Search,
  Filter,
  Trash2,
  Download,
  Play,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Eye,
  X,
  Sparkles,
} from 'lucide-react';

interface DashboardScreenProps {
  submissions: QuizSubmission[];
  questions: QuizQuestion[];
  onStartQuiz: () => void;
  onResetData: () => void;
  onOpenCreateModal: () => void;
}

export const DashboardScreen: React.FC<DashboardScreenProps> = ({
  submissions,
  questions,
  onStartQuiz,
  onResetData,
  onOpenCreateModal,
}) => {
  const { theme } = useTheme();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterTier, setFilterTier] = useState<string>('all');
  const [inspectSubmission, setInspectSubmission] = useState<QuizSubmission | null>(null);
  const [isConfirmingReset, setIsConfirmingReset] = useState(false);

  // Stats calculation
  const totalSubmissions = submissions.length;
  const avgScore =
    totalSubmissions > 0
      ? (submissions.reduce((acc, curr) => acc + curr.score, 0) / totalSubmissions).toFixed(1)
      : '0';
  const soulmatesCount = submissions.filter(s => s.score >= 9).length;
  const soulmatePercent =
    totalSubmissions > 0 ? Math.round((soulmatesCount / totalSubmissions) * 100) : 0;

  // Filtered and sorted submissions (highest score first, then newest)
  const filteredSubmissions = [...submissions]
    .sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      return b.submittedAt - a.submittedAt;
    })
    .filter(s => {
      const matchSearch =
        s.playerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (s.isAnonymous && 'ẩn danh'.includes(searchTerm.toLowerCase()));

      if (!matchSearch) return false;
      if (filterTier === 'all') return true;
      if (filterTier === 'soulmate') return s.score >= 9;
      if (filterTier === 'close') return s.score >= 7 && s.score < 9;
      if (filterTier === 'casual') return s.score >= 4 && s.score < 7;
      if (filterTier === 'stranger') return s.score < 4;
      if (filterTier === 'anonymous') return s.isAnonymous;
      return true;
    });

  const handleExportJSON = () => {
    sound.playClick();
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(submissions, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `danh_sach_quiz_thien_nhan_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const formatTimestamp = (timestamp: number) => {
    const diff = Date.now() - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Vừa xong';
    if (minutes < 60) return `${minutes} phút trước`;
    if (hours < 24) return `${hours} giờ trước`;
    return `${days} ngày trước`;
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 sm:py-12 animate-in fade-in duration-300">
      {/* Dashboard Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 mb-2">
            <Trophy className="w-3.5 h-3.5" />
            <span>Khu Vực Quản Trị & Bảng Vàng</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            Dashboard Đỗ Thiện Nhân
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Xem ai đã tham gia làm quiz, đạt bao nhiêu điểm và ai là người hiểu Nhân nhất!
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => {
              sound.playClick();
              onStartQuiz();
            }}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-sm text-white shadow-sm hover:shadow-md transition-all active:scale-95 bg-gradient-to-r ${theme.gradientFrom} ${theme.gradientTo}`}
          >
            <Play className="w-4 h-4 fill-current" />
            <span>Làm Bài Ngay</span>
          </button>

          <button
            onClick={handleExportJSON}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs sm:text-sm font-semibold hover:bg-slate-50 dark:hover:bg-slate-750 transition-colors shadow-2xs"
            title="Tải file JSON danh sách người làm bài"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span className="hidden sm:inline">Xuất Danh Sách</span>
          </button>

          <button
            onClick={() => setIsConfirmingReset(true)}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl border border-rose-200 dark:border-rose-900/60 bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 text-xs sm:text-sm font-semibold hover:bg-rose-100 dark:hover:bg-rose-900/60 transition-colors"
            title="Đặt lại dữ liệu ban đầu"
          >
            <Trash2 className="w-4 h-4" />
            <span className="hidden sm:inline">Đặt lại</span>
          </button>
        </div>
      </div>

      {/* KPI Overview Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Tổng Lượt Chơi</span>
            <Users className="w-5 h-5 text-sky-500" />
          </div>
          <div className="text-3xl font-black text-slate-900 dark:text-white tabular-nums mt-3">
            {totalSubmissions}
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Bạn bè và người tham gia
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Điểm Trung Bình</span>
            <Award className="w-5 h-5 text-amber-500" />
          </div>
          <div className="text-3xl font-black text-slate-900 dark:text-white tabular-nums mt-3">
            {avgScore} <span className="text-lg text-slate-400 font-semibold">/ 10</span>
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Độ hiểu biết về Thiện Nhân
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Tỷ Lệ Tri Kỷ (≥9đ)</span>
            <Sparkles className="w-5 h-5 text-purple-500" />
          </div>
          <div className="text-3xl font-black text-slate-900 dark:text-white tabular-nums mt-3">
            {soulmatePercent}%
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {soulmatesCount} bạn đạt danh hiệu tri kỷ
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Chủ Nhân Quiz</span>
            <Trophy className="w-5 h-5 text-emerald-500" />
          </div>
          <div className="text-xl font-bold text-slate-900 dark:text-white mt-3 truncate">
            Đỗ Thiện Nhân
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Lớp 9A2 · Đam mê Tin học & Bóng đá
          </div>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm mb-6 flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 transform -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Tìm theo tên bạn bè..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          {[
            { id: 'all', label: 'Tất cả' },
            { id: 'soulmate', label: '🏆 Tri kỷ (9-10đ)' },
            { id: 'close', label: '🤝 Bạn thân (7-8đ)' },
            { id: 'casual', label: '👋 Bạn bè (4-6đ)' },
            { id: 'stranger', label: '👀 Người lạ (<4đ)' },
          ].map(f => (
            <button
              key={f.id}
              onClick={() => {
                sound.playClick();
                setFilterTier(f.id);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                filterTier === f.id
                  ? `${theme.badgeBg} font-bold shadow-2xs`
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Leaderboard Table / Card List */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden">
        {filteredSubmissions.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <Users className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto" />
            <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">
              Không tìm thấy bài làm nào
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Chưa có bạn bè nào phù hợp với bộ lọc hiện tại. Thử đổi từ khóa hoặc làm bài ngay nhé!
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {filteredSubmissions.map((sub, index) => {
              const avatar = CUTE_AVATARS.find(a => a.id === sub.avatarId) || CUTE_AVATARS[0];
              const isTop1 = index === 0 && sub.score >= 9;
              const isTop2 = index === 1 && sub.score >= 8;
              const isTop3 = index === 2 && sub.score >= 7;

              return (
                <div
                  key={sub.id}
                  className="p-4 sm:p-5 flex items-center justify-between gap-4 hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                >
                  {/* Left: Rank & Player Info */}
                  <div className="flex items-center gap-3.5 sm:gap-4 min-w-0">
                    {/* Rank Badge */}
                    <div className="w-7 sm:w-8 text-center shrink-0">
                      {isTop1 ? (
                        <span className="text-xl" title="Hạng 1 - Tri Kỷ Vàng">🥇</span>
                      ) : isTop2 ? (
                        <span className="text-xl" title="Hạng 2 - Tri Kỷ Bạc">🥈</span>
                      ) : isTop3 ? (
                        <span className="text-xl" title="Hạng 3 - Tri Kỷ Đồng">🥉</span>
                      ) : (
                        <span className="text-xs sm:text-sm font-bold text-slate-400 dark:text-slate-500 tabular-nums">
                          #{index + 1}
                        </span>
                      )}
                    </div>

                    {/* Cute Avatar */}
                    <div
                      className={`w-11 h-11 sm:w-12 sm:h-12 rounded-2xl flex items-center justify-center text-2xl sm:text-3xl shrink-0 shadow-2xs ${avatar.bgColor}`}
                    >
                      {avatar.emoji}
                    </div>

                    {/* Name & Metadata */}
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm sm:text-base font-bold text-slate-900 dark:text-white truncate">
                          {sub.playerName}
                        </span>
                        {sub.isAnonymous && (
                          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 shrink-0">
                            Ẩn danh
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                        <span className="font-medium text-slate-600 dark:text-slate-300">
                          {sub.feedbackTitle}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{formatTimestamp(sub.submittedAt)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Right: Score & View Details Button */}
                  <div className="flex items-center gap-3 sm:gap-5 shrink-0">
                    <div className="text-right">
                      <div className="text-base sm:text-lg font-black text-slate-900 dark:text-white tabular-nums">
                        {sub.score}{' '}
                        <span className="text-xs sm:text-sm font-normal text-slate-400">
                          / {sub.totalQuestions}
                        </span>
                      </div>
                      <div className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">
                        {sub.percentage}% đúng
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        sound.playClick();
                        setInspectSubmission(sub);
                      }}
                      className="p-2 sm:px-3 sm:py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-750 transition-colors shadow-2xs flex items-center gap-1.5"
                      title="Xem chi tiết các câu trả lời"
                    >
                      <Eye className="w-3.5 h-3.5 text-sky-500" />
                      <span className="hidden sm:inline">Chi Tiết</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Inspect Submission Modal */}
      {inspectSubmission && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-2xl w-full max-h-[85vh] overflow-hidden flex flex-col shadow-2xl border border-slate-200 dark:border-slate-800">
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-3xl">
                  {CUTE_AVATARS.find(a => a.id === inspectSubmission.avatarId)?.emoji || '✨'}
                </span>
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <span>{inspectSubmission.playerName}</span>
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 font-bold">
                      {inspectSubmission.score} / {inspectSubmission.totalQuestions} Điểm
                    </span>
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {inspectSubmission.feedbackQuote}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setInspectSubmission(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Question Answers List */}
            <div className="p-5 overflow-y-auto space-y-3 divide-y divide-slate-100 dark:divide-slate-800">
              {questions.map((q, idx) => {
                const ansId = inspectSubmission.answers[q.id];
                const isCorrect = ansId === q.correctOptionId;
                const chosenOption = q.options.find(o => o.id === ansId);
                const correctOption = q.options.find(o => o.id === q.correctOptionId);

                return (
                  <div key={q.id} className="pt-3 first:pt-0 space-y-1.5">
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-xs font-semibold text-slate-900 dark:text-white">
                        Câu {idx + 1}: {q.question}
                      </span>
                      {isCorrect ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                      ) : (
                        <XCircle className="w-4 h-4 text-rose-500 shrink-0" />
                      )}
                    </div>
                    <div className="text-xs flex flex-wrap gap-2">
                      <span className="text-slate-500">
                        Đã chọn:{' '}
                        <strong className={isCorrect ? 'text-emerald-600' : 'text-rose-600'}>
                          {chosenOption ? `${ansId}. ${chosenOption.text}` : 'Chưa trả lời'}
                        </strong>
                      </span>
                      {!isCorrect && (
                        <span className="text-slate-500">
                          (Đáp án đúng:{' '}
                          <strong className="text-emerald-600">
                            {q.correctOptionId}. {correctOption?.text}
                          </strong>
                          )
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 flex justify-end">
              <button
                onClick={() => setInspectSubmission(null)}
                className="px-4 py-2 text-xs sm:text-sm font-semibold rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-600"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirm Reset Dialog */}
      {isConfirmingReset && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl border border-slate-200 dark:border-slate-800">
            <div className="w-12 h-12 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-600 mx-auto flex items-center justify-center">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              Đặt lại bảng điểm?
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Thao tác này sẽ khôi phục lại danh sách bài làm mặc định ban đầu. Bạn có chắc chắn không?
            </p>
            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => setIsConfirmingReset(false)}
                className="py-2.5 px-4 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                Hủy bỏ
              </button>
              <button
                onClick={() => {
                  onResetData();
                  setIsConfirmingReset(false);
                }}
                className="py-2.5 px-4 rounded-xl bg-rose-600 text-white text-xs font-bold hover:bg-rose-700 transition-colors"
              >
                Xác nhận đặt lại
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
