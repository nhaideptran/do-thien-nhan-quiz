import React, { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { QuizQuestion } from '../types';
import { sound } from '../utils/sound';
import {
  X,
  PlusCircle,
  Sparkles,
  Check,
  Share2,
  HelpCircle,
} from 'lucide-react';

interface CreateQuizModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddCustomQuestion: (newQuestion: QuizQuestion) => void;
  totalQuestions: number;
}

export const CreateQuizModal: React.FC<CreateQuizModalProps> = ({
  isOpen,
  onClose,
  onAddCustomQuestion,
  totalQuestions,
}) => {
  const { theme } = useTheme();
  const [tab, setTab] = useState<'add_question' | 'share_quiz'>('add_question');

  // Add question state
  const [questionText, setQuestionText] = useState('');
  const [optA, setOptA] = useState('');
  const [optB, setOptB] = useState('');
  const [optC, setOptC] = useState('');
  const [optD, setOptD] = useState('');
  const [correctOption, setCorrectOption] = useState<'A' | 'B' | 'C' | 'D'>('A');
  const [explanation, setExplanation] = useState('');
  const [messiComment, setMessiComment] = useState('');
  const [tag, setTag] = useState('Bí mật mới');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  // Share state
  const [copiedLink, setCopiedLink] = useState(false);

  if (!isOpen) return null;

  const handleAddQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!questionText.trim() || !optA.trim() || !optB.trim() || !optC.trim() || !optD.trim()) {
      setError('Vui lòng điền đầy đủ câu hỏi và cả 4 phương án A, B, C, D nhé!');
      sound.playIncorrect();
      return;
    }

    const newQ: QuizQuestion = {
      id: totalQuestions + 1,
      question: questionText.trim(),
      subtitle: 'Câu hỏi mới do bạn đóng góp cho Đỗ Thiện Nhân!',
      tag: tag.trim() || 'Tình bạn',
      iconName: 'Sparkles',
      options: [
        { id: 'A', text: optA.trim() },
        { id: 'B', text: optB.trim() },
        { id: 'C', text: optC.trim() },
        { id: 'D', text: optD.trim() },
      ],
      correctOptionId: correctOption,
      explanation:
        explanation.trim() ||
        `Đáp án chính xác là ${correctOption}! Cảm ơn bạn đã đóng góp câu hỏi tuyệt vời này!`,
      messiComment:
        messiComment.trim() ||
        'Câu hỏi này hay quá! Messi cũng phải vắt óc suy nghĩ một chút mới trả lời được!',
    };

    sound.playCorrect();
    onAddCustomQuestion(newQ);
    setSuccess(true);
    setTimeout(() => {
      setSuccess(false);
      onClose();
      // Reset form
      setQuestionText('');
      setOptA('');
      setOptB('');
      setOptC('');
      setOptD('');
      setExplanation('');
      setMessiComment('');
    }, 1500);
  };

  const handleCopyShareLink = async () => {
    sound.playClick();
    const currentUrl = window.location.href;
    if (navigator.clipboard) {
      await navigator.clipboard.writeText(currentUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl border border-slate-200 dark:border-slate-800">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div
              className={`w-8 h-8 rounded-xl flex items-center justify-center text-white bg-gradient-to-br ${theme.gradientFrom} ${theme.gradientTo}`}
            >
              <PlusCircle className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                Tạo & Mở Rộng Quiz Bạn Bè
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Thêm câu hỏi mới vào bộ Quiz Đỗ Thiện Nhân hoặc lấy link chia sẻ
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="p-3 bg-slate-50 dark:bg-slate-800/40 border-b border-slate-100 dark:border-slate-800 flex gap-2">
          <button
            type="button"
            onClick={() => setTab('add_question')}
            className={`flex-1 py-2 text-xs sm:text-sm font-bold rounded-xl transition-colors ${
              tab === 'add_question'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            + Thêm Câu Hỏi Mới
          </button>
          <button
            type="button"
            onClick={() => setTab('share_quiz')}
            className={`flex-1 py-2 text-xs sm:text-sm font-bold rounded-xl transition-colors ${
              tab === 'share_quiz'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            🔗 Chia Sẻ Quiz Cho Bạn Bè
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {tab === 'add_question' ? (
            <form onSubmit={handleAddQuestion} className="space-y-4">
              {success && (
                <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 text-emerald-800 dark:text-emerald-300 text-xs font-bold flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-500" />
                  <span>Đã thêm câu hỏi thành công vào bộ quiz! Đang cập nhật...</span>
                </div>
              )}

              {error && (
                <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 text-rose-800 dark:text-rose-300 text-xs font-medium">
                  {error}
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Nội dung câu hỏi:
                </label>
                <input
                  type="text"
                  placeholder="Ví dụ: Thiện Nhân thích ăn món gì nhất khi tan học?"
                  value={questionText}
                  onChange={e => setQuestionText(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              {/* Options A, B, C, D */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {(['A', 'B', 'C', 'D'] as const).map(optLetter => {
                  const val =
                    optLetter === 'A'
                      ? optA
                      : optLetter === 'B'
                      ? optB
                      : optLetter === 'C'
                      ? optC
                      : optD;
                  const setVal =
                    optLetter === 'A'
                      ? setOptA
                      : optLetter === 'B'
                      ? setOptB
                      : optLetter === 'C'
                      ? setOptC
                      : setOptD;

                  return (
                    <div key={optLetter} className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 flex items-center justify-between">
                        <span>Phương án {optLetter}:</span>
                        <button
                          type="button"
                          onClick={() => setCorrectOption(optLetter)}
                          className={`text-[10px] px-1.5 py-0.5 rounded ${
                            correctOption === optLetter
                              ? 'bg-emerald-500 text-white font-bold'
                              : 'text-slate-400 hover:text-slate-600'
                          }`}
                        >
                          {correctOption === optLetter ? '✓ Đáp án đúng' : 'Chọn làm đáp án đúng'}
                        </button>
                      </label>
                      <input
                        type="text"
                        placeholder={`Lựa chọn ${optLetter}...`}
                        value={val}
                        onChange={e => setVal(e.target.value)}
                        className={`w-full px-3 py-2 rounded-xl border text-xs sm:text-sm ${
                          correctOption === optLetter
                            ? 'border-emerald-500 ring-1 ring-emerald-400 bg-emerald-50/20 dark:bg-emerald-950/20'
                            : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800'
                        } text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none`}
                      />
                    </div>
                  );
                })}
              </div>

              {/* Fact Explanation */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Giải thích vui / Sự thật về Thiện Nhân (Hiển thị khi giải đáp):
                </label>
                <input
                  type="text"
                  placeholder="Ví dụ: Thiện Nhân mê món này vì thơm ngon và bổ dưỡng!"
                  value={explanation}
                  onChange={e => setExplanation(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              {/* Messi comment */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Lời bình luận dễ thương của trợ lý Messi:
                </label>
                <input
                  type="text"
                  placeholder="Ví dụ: Messi cũng thích món này lắm nè!"
                  value={messiComment}
                  onChange={e => setMessiComment(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 text-xs sm:text-sm font-bold text-white rounded-xl shadow-md ${theme.primaryBg} ${theme.primaryHover}`}
                >
                  + Lưu Câu Hỏi Này
                </button>
              </div>
            </form>
          ) : (
            <div className="space-y-4 text-center py-4">
              <div className="w-16 h-16 rounded-3xl bg-sky-100 dark:bg-sky-950/60 text-sky-600 mx-auto flex items-center justify-center">
                <Share2 className="w-8 h-8" />
              </div>
              <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                Mời Bạn Bè Tham Gia Quiz
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 max-w-md mx-auto leading-relaxed">
                Sao chép liên kết ứng dụng bên dưới để gửi cho bạn bè trong lớp 9A2 hoặc người thân thử tài hiểu Đỗ Thiện Nhân!
              </p>

              <div className="flex items-center gap-2 p-2 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                <input
                  type="text"
                  readOnly
                  value={typeof window !== 'undefined' ? window.location.href : ''}
                  className="w-full bg-transparent text-xs font-mono px-2 text-slate-700 dark:text-slate-300 focus:outline-none select-all"
                />
                <button
                  onClick={handleCopyShareLink}
                  className={`px-4 py-2 text-xs font-bold rounded-xl text-white shrink-0 ${
                    copiedLink ? 'bg-emerald-600' : `${theme.primaryBg} ${theme.primaryHover}`
                  }`}
                >
                  {copiedLink ? 'Đã chép!' : 'Sao chép link'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
