import React, { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { QuizQuestion, AvatarOption } from '../types';
import { sound } from '../utils/sound';
import {
  CheckCircle2,
  XCircle,
  ArrowRight,
  Trophy,
  HelpCircle,
  Sparkles,
  Info,
} from 'lucide-react';

interface QuizScreenProps {
  questions: QuizQuestion[];
  playerName: string;
  isAnonymous: boolean;
  avatar: AvatarOption;
  onCompleteQuiz: (answers: Record<number, string>, timeSpentSeconds: number) => void;
  onSetMessiMessage: (msg: string, qNum: number) => void;
  onCancelQuiz: () => void;
}

export const QuizScreen: React.FC<QuizScreenProps> = ({
  questions,
  playerName,
  isAnonymous,
  avatar,
  onCompleteQuiz,
  onSetMessiMessage,
  onCancelQuiz,
}) => {
  const { theme } = useTheme();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, string>>({});
  const [hasAnsweredCurrent, setHasAnsweredCurrent] = useState(false);
  const [currentSelectedOption, setCurrentSelectedOption] = useState<string | null>(null);
  const [startTime] = useState<number>(Date.now());

  const currentQuestion = questions[currentIndex];
  const progressPercent = Math.round(((currentIndex + 1) / questions.length) * 100);

  const handleSelectOption = (optionId: string) => {
    if (hasAnsweredCurrent) return; // Prevent changing after revealing

    const isCorrect = optionId === currentQuestion.correctOptionId;
    if (isCorrect) {
      sound.playCorrect();
    } else {
      sound.playIncorrect();
    }

    setCurrentSelectedOption(optionId);
    setHasAnsweredCurrent(true);

    const updatedAnswers = {
      ...selectedAnswers,
      [currentQuestion.id]: optionId,
    };
    setSelectedAnswers(updatedAnswers);

    // Update Messi mascot comment
    onSetMessiMessage(currentQuestion.messiComment, currentIndex + 1);
  };

  const handleNext = () => {
    sound.playClick();
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setHasAnsweredCurrent(false);
      setCurrentSelectedOption(null);
      onSetMessiMessage(
        questions[currentIndex + 1].messiComment,
        currentIndex + 2
      );
    } else {
      // Finished all questions!
      const totalTimeSpent = Math.max(1, Math.round((Date.now() - startTime) / 1000));
      onCompleteQuiz(selectedAnswers, totalTimeSpent);
    }
  };

  const isCurrentCorrect = currentSelectedOption === currentQuestion.correctOptionId;

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6 sm:py-10 animate-in fade-in duration-200">
      {/* Top Header Bar: Player Info & Progress */}
      <div className="mb-6 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="text-2xl p-1 rounded-xl bg-slate-100 dark:bg-slate-800">
              {avatar.emoji}
            </span>
            <div>
              <div className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <span>{playerName}</span>
                {isAnonymous && (
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                    Ẩn danh
                  </span>
                )}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                Đang thử thách hiểu Đỗ Thiện Nhân
              </div>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              Tiến Độ
            </span>
            <div className="text-sm sm:text-base font-extrabold text-slate-800 dark:text-slate-100 tabular-nums">
              Câu {currentIndex + 1} / {questions.length}
            </div>
          </div>
        </div>

        {/* Animated Progress Bar */}
        <div className="w-full h-3 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden p-0.5 border border-slate-200/60 dark:border-slate-700/60">
          <div
            className={`h-full rounded-full transition-all duration-300 bg-gradient-to-r ${theme.gradientFrom} ${theme.gradientTo}`}
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Main Question Card */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 shadow-xl border border-slate-200 dark:border-slate-800 relative">
        {/* Category & Step Tag */}
        <div className="flex items-center justify-between gap-2 mb-4">
          <span className={`text-xs font-bold px-3 py-1 rounded-full ${theme.badgeBg}`}>
            {currentQuestion.tag}
          </span>
          <span className="text-xs font-semibold text-slate-400 dark:text-slate-500">
            {progressPercent}% Hoàn thành
          </span>
        </div>

        {/* Question Heading */}
        <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white leading-snug mb-2">
          {currentQuestion.question}
        </h2>
        {currentQuestion.subtitle && (
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mb-6">
            {currentQuestion.subtitle}
          </p>
        )}

        {/* Options List */}
        <div className="space-y-3 mt-6">
          {currentQuestion.options.map(option => {
            const isSelected = currentSelectedOption === option.id;
            const isCorrect = option.id === currentQuestion.correctOptionId;

            let optionStyle =
              'border-slate-200 dark:border-slate-700/80 bg-slate-50 dark:bg-slate-800/40 text-slate-800 dark:text-slate-100 hover:bg-white dark:hover:bg-slate-800 hover:border-slate-300 dark:hover:border-slate-600';
            let badgeStyle =
              'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200';

            if (hasAnsweredCurrent) {
              if (isCorrect) {
                // Correct answer is always green
                optionStyle =
                  'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-100 ring-2 ring-emerald-400';
                badgeStyle = 'bg-emerald-500 text-white';
              } else if (isSelected && !isCorrect) {
                // Selected wrong answer is red
                optionStyle =
                  'border-rose-500 bg-rose-50 dark:bg-rose-950/40 text-rose-900 dark:text-rose-100 ring-2 ring-rose-400';
                badgeStyle = 'bg-rose-500 text-white';
              } else {
                optionStyle =
                  'opacity-40 border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/20 text-slate-500 dark:text-slate-500';
              }
            }

            return (
              <button
                key={option.id}
                type="button"
                disabled={hasAnsweredCurrent}
                onClick={() => handleSelectOption(option.id)}
                className={`w-full flex items-center justify-between p-4 rounded-2xl border text-left font-medium text-sm sm:text-base transition-all duration-150 ${optionStyle} ${
                  !hasAnsweredCurrent ? 'cursor-pointer active:scale-[0.99]' : 'cursor-default'
                }`}
              >
                <div className="flex items-center gap-3.5 pr-2">
                  <span
                    className={`w-8 h-8 rounded-xl font-bold flex items-center justify-center text-sm shrink-0 transition-colors ${badgeStyle}`}
                  >
                    {option.id}
                  </span>
                  <span className="leading-relaxed">{option.text}</span>
                </div>

                {hasAnsweredCurrent && (
                  <div className="shrink-0">
                    {isCorrect ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                    ) : isSelected ? (
                      <XCircle className="w-5 h-5 text-rose-500" />
                    ) : null}
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Fact Explanation Card (Reveals after answering) */}
        {hasAnsweredCurrent && (
          <div
            className={`mt-6 p-4 rounded-2xl border animate-in fade-in slide-in-from-top-2 duration-200 ${
              isCurrentCorrect
                ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800/60'
                : 'bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800/60'
            }`}
          >
            <div className="flex items-start gap-3">
              <div
                className={`p-1.5 rounded-lg shrink-0 mt-0.5 ${
                  isCurrentCorrect
                    ? 'bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300'
                    : 'bg-amber-100 dark:bg-amber-900/60 text-amber-700 dark:text-amber-300'
                }`}
              >
                {isCurrentCorrect ? (
                  <Sparkles className="w-4 h-4" />
                ) : (
                  <Info className="w-4 h-4" />
                )}
              </div>
              <div className="space-y-1">
                <div
                  className={`text-xs font-bold uppercase tracking-wider ${
                    isCurrentCorrect
                      ? 'text-emerald-800 dark:text-emerald-300'
                      : 'text-amber-800 dark:text-amber-300'
                  }`}
                >
                  {isCurrentCorrect ? 'Chuẩn Xác 100%!' : 'Bí mật về Đỗ Thiện Nhân:'}
                </div>
                <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed">
                  {currentQuestion.explanation}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Bottom Actions */}
        <div className="mt-8 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onCancelQuiz}
            className="text-xs font-medium text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 underline"
          >
            Thoát về trang chủ
          </button>

          {hasAnsweredCurrent ? (
            <button
              type="button"
              onClick={handleNext}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl text-sm sm:text-base font-bold text-white shadow-md hover:shadow-lg transition-transform active:scale-95 bg-gradient-to-r ${theme.gradientFrom} ${theme.gradientTo}`}
            >
              <span>
                {currentIndex < questions.length - 1 ? 'Câu Tiếp Theo' : 'Xem Kết Quả Cuối Cùng'}
              </span>
              {currentIndex < questions.length - 1 ? (
                <ArrowRight className="w-4 h-4" />
              ) : (
                <Trophy className="w-4 h-4 text-amber-300" />
              )}
            </button>
          ) : (
            <div className="text-xs text-slate-400 dark:text-slate-500 italic">
              Chọn 1 trong 4 phương án trên để tiếp tục nhé
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
