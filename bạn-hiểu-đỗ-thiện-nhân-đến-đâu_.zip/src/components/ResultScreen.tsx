import React, { useEffect, useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { QuizSubmission, QuizQuestion, AvatarOption } from '../types';
import { getFeedbackForScore, CUTE_AVATARS } from '../data/quizData';
import { sound } from '../utils/sound';
import confetti from 'canvas-confetti';
import {
  Trophy,
  RotateCcw,
  LayoutDashboard,
  Share2,
  Check,
  CheckCircle2,
  XCircle,
  Sparkles,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

interface ResultScreenProps {
  submission: QuizSubmission;
  questions: QuizQuestion[];
  onPlayAgain: () => void;
  onViewDashboard: () => void;
}

export const ResultScreen: React.FC<ResultScreenProps> = ({
  submission,
  questions,
  onPlayAgain,
  onViewDashboard,
}) => {
  const { theme } = useTheme();
  const [copied, setCopied] = useState(false);
  const [showReview, setShowReview] = useState(false);

  const feedback = getFeedbackForScore(submission.score, submission.totalQuestions);
  const avatar = CUTE_AVATARS.find(a => a.id === submission.avatarId) || CUTE_AVATARS[0];

  useEffect(() => {
    sound.playFanfare();

    if (feedback.confetti) {
      // Fire confetti burst!
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
        const timeout = setTimeout(() => {
          confetti({
            particleCount: 50,
            angle: 60,
            spread: 55,
            origin: { x: 0 },
          });
          confetti({
            particleCount: 50,
            angle: 120,
            spread: 55,
            origin: { x: 1 },
          });
        }, 300);
        return () => clearTimeout(timeout);
      } catch {
        // Safe fallback
      }
    }
  }, [feedback.confetti]);

  const handleShare = async () => {
    sound.playClick();
    const shareText = `🎉 Mình vừa đạt ${submission.score}/${submission.totalQuestions} điểm trong Quiz "Bạn hiểu Đỗ Thiện Nhân đến đâu?"!\n🏆 Danh hiệu: ${feedback.title}\n💬 Nhận xét: ${feedback.quote}\n👉 Thử tài hiểu bạn thân Đỗ Thiện Nhân 9A2 ngay hôm nay!`;

    if (navigator.clipboard) {
      await navigator.clipboard.writeText(shareText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8 sm:py-12 animate-in fade-in duration-300">
      {/* Main Certificate / Result Card */}
      <div className="relative rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden p-6 sm:p-10 text-center">
        {/* Decorative Top Accent Glow */}
        <div
          className={`absolute top-0 left-0 right-0 h-3 bg-gradient-to-r ${theme.gradientFrom} ${theme.gradientTo}`}
        />

        {/* Avatar Badge */}
        <div className="relative inline-block mb-4 mt-2">
          <div
            className={`w-24 h-24 sm:w-28 sm:h-28 rounded-3xl mx-auto flex items-center justify-center text-5xl sm:text-6xl shadow-md border-4 border-white dark:border-slate-800 ${avatar.bgColor}`}
          >
            {avatar.emoji}
          </div>
          <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 px-3 py-0.5 rounded-full text-xs font-bold bg-amber-500 text-white shadow-sm whitespace-nowrap">
            {feedback.badge}
          </div>
        </div>

        {/* Player Name & Subtitle */}
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-3">
          {submission.playerName}
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
          Đã hoàn thành bài kiểm tra tình bạn cùng Đỗ Thiện Nhân
        </p>

        {/* Score Pill Display */}
        <div className="my-6 inline-flex flex-col items-center justify-center p-6 rounded-3xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 min-w-56">
          <div className="text-4xl sm:text-5xl font-black text-slate-900 dark:text-white tabular-nums tracking-tight">
            {submission.score}{' '}
            <span className="text-2xl text-slate-400 font-semibold">/ {submission.totalQuestions}</span>
          </div>
          <div className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mt-1">
            Đúng {submission.percentage}% câu hỏi · Thời gian: {submission.timeSpentSeconds}s
          </div>
        </div>

        {/* Funny Title & Feedback Quote */}
        <div className="max-w-lg mx-auto space-y-2 mb-8">
          <h2 className="text-xl sm:text-2xl font-bold text-slate-800 dark:text-slate-100 flex items-center justify-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-500" />
            <span>{feedback.title}</span>
          </h2>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed italic">
            "{feedback.quote}"
          </p>
        </div>

        {/* Messi's Personal Reaction Box */}
        <div className="p-4 rounded-2xl bg-sky-50 dark:bg-sky-950/40 border border-sky-100 dark:border-sky-900/60 text-left flex items-start gap-3.5 mb-8">
          <img
            src="/src/assets/images/messi_mascot_chibi_1792832639977.jpg"
            alt="Messi"
            className="w-12 h-12 rounded-full border border-sky-300 object-cover shrink-0"
            referrerPolicy="no-referrer"
          />
          <div>
            <div className="text-xs font-bold text-sky-700 dark:text-sky-300 uppercase tracking-wider">
              Lời nhắn từ trợ lý Messi:
            </div>
            <div className="text-xs sm:text-sm text-slate-700 dark:text-slate-200 mt-0.5 leading-relaxed">
              {feedback.messiReaction}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <button
            onClick={onPlayAgain}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 font-bold text-sm hover:bg-slate-50 dark:hover:bg-slate-750 transition-colors shadow-2xs"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Làm Lại Quiz</span>
          </button>

          <button
            onClick={handleShare}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 font-bold text-sm hover:bg-slate-50 dark:hover:bg-slate-750 transition-colors shadow-2xs"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-emerald-500" />
                <span className="text-emerald-600 dark:text-emerald-400">Đã Sao Chép!</span>
              </>
            ) : (
              <>
                <Share2 className="w-4 h-4 text-sky-500" />
                <span>Chia Sẻ Kết Quả</span>
              </>
            )}
          </button>

          <button
            onClick={onViewDashboard}
            className={`flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-bold text-sm text-white shadow-md hover:shadow-lg transition-transform active:scale-95 bg-gradient-to-r ${theme.gradientFrom} ${theme.gradientTo}`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>Vào Dashboard</span>
          </button>
        </div>
      </div>

      {/* Review Answers Accordion */}
      <div className="mt-8">
        <button
          onClick={() => {
            sound.playClick();
            setShowReview(!showReview);
          }}
          className="w-full flex items-center justify-between p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm text-sm sm:text-base font-bold text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-850 transition-colors"
        >
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-500" />
            <span>Xem Chi Tiết Đáp Án & Bí Mật Đỗ Thiện Nhân</span>
          </div>
          {showReview ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
        </button>

        {showReview && (
          <div className="mt-4 space-y-4 animate-in fade-in duration-200">
            {questions.map((q, idx) => {
              const playerAnsId = submission.answers[q.id];
              const isCorrect = playerAnsId === q.correctOptionId;
              const playerOption = q.options.find(o => o.id === playerAnsId);
              const correctOption = q.options.find(o => o.id === q.correctOptionId);

              return (
                <div
                  key={q.id}
                  className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-2.5"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-2.5">
                      <span className="text-xs font-bold px-2 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 shrink-0">
                        Câu {idx + 1}
                      </span>
                      <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white leading-snug">
                        {q.question}
                      </h3>
                    </div>
                    {isCorrect ? (
                      <span className="flex items-center gap-1 text-xs font-bold text-emerald-600 dark:text-emerald-400 shrink-0">
                        <CheckCircle2 className="w-4 h-4" />
                        Đúng
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-xs font-bold text-rose-600 dark:text-rose-400 shrink-0">
                        <XCircle className="w-4 h-4" />
                        Sai
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs sm:text-sm pt-1">
                    <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/80">
                      <span className="text-slate-400 dark:text-slate-500 font-semibold block text-[11px]">
                        Lựa chọn của bạn:
                      </span>
                      <span className={isCorrect ? 'text-emerald-600 font-bold' : 'text-rose-600 font-bold'}>
                        {playerAnsId ? `${playerAnsId}. ${playerOption?.text || ''}` : 'Chưa chọn'}
                      </span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/40">
                      <span className="text-emerald-600/80 dark:text-emerald-400/80 font-semibold block text-[11px]">
                        Đáp án chính xác:
                      </span>
                      <span className="text-emerald-700 dark:text-emerald-300 font-bold">
                        {q.correctOptionId}. {correctOption?.text}
                      </span>
                    </div>
                  </div>

                  <div className="text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/30 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
                    <span className="font-bold text-slate-700 dark:text-slate-200">Ghi chú vui: </span>
                    {q.explanation}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
