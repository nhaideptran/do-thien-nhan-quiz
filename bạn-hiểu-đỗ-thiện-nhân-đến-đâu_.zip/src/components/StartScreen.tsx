import React, { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { CUTE_AVATARS, THEMES } from '../data/quizData';
import { sound } from '../utils/sound';
import {
  Shuffle,
  Sparkles,
  Pencil,
  Check,
  ChevronDown,
  X,
  Play,
  Lightbulb,
  Share2,
  Copy,
} from 'lucide-react';
import { ThemeColorKey } from '../types';

interface StartScreenProps {
  onStartQuiz: (playerName: string, isAnonymous: boolean, avatarId: string) => void;
  onViewDashboard: () => void;
  onOpenCreateModal: () => void;
  totalSubmissionsCount: number;
}

export const StartScreen: React.FC<StartScreenProps> = ({
  onStartQuiz,
  onViewDashboard,
}) => {
  const { theme, themeKey, setThemeKey } = useTheme();
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [playerName, setPlayerName] = useState('');
  const [selectedAvatarId, setSelectedAvatarId] = useState('gamer');
  const [nameError, setNameError] = useState('');
  const [isAvatarModalOpen, setIsAvatarModalOpen] = useState(false);
  const [isThemePickerOpen, setIsThemePickerOpen] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const handleCopyLink = async () => {
    sound.playClick();
    // Use the official public Shared App URL if in AI Studio, or fallback to current origin
    const publicUrl = window.location.href.includes('run.app')
      ? window.location.href.split('?')[0].replace('-dev-', '-pre-')
      : window.location.href;

    const shareContent = `🎮 Bạn hiểu Đỗ Thiện Nhân (9A2) đến đâu?\nVào làm thử Quiz xem bạn có phải tri kỷ của Nhân không nhé!\n👉 Link làm bài ngay: ${publicUrl}`;

    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(shareContent);
        setCopiedLink(true);
        setTimeout(() => setCopiedLink(false), 3000);
      }
    } catch {
      // Fallback
    }
  };

  const selectedAvatarIndex = CUTE_AVATARS.findIndex(a => a.id === selectedAvatarId);
  const selectedAvatar = CUTE_AVATARS[selectedAvatarIndex >= 0 ? selectedAvatarIndex : 0];
  const avatarNumber = (selectedAvatarIndex >= 0 ? selectedAvatarIndex : 0) + 1;

  const handleRandomizeAvatar = () => {
    sound.playClick();
    const available = CUTE_AVATARS.filter(a => a.id !== selectedAvatarId);
    const randomIndex = Math.floor(Math.random() * available.length);
    setSelectedAvatarId(available[randomIndex].id);
  };

  const handleModeSelect = (anonymous: boolean) => {
    sound.playClick();
    setIsAnonymous(anonymous);
    setNameError('');
    if (anonymous) {
      if (!playerName.trim()) {
        setPlayerName('Người Bạn Bí Ẩn');
      }
    } else {
      if (playerName === 'Người Bạn Bí Ẩn') {
        setPlayerName('');
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalName = isAnonymous
      ? (playerName.trim() || 'Người Bạn Bí Ẩn')
      : playerName.trim();

    if (!isAnonymous && !finalName) {
      setNameError('Vui lòng nhập tên của bạn hoặc chọn chế độ Ẩn danh nhé!');
      sound.playIncorrect();
      return;
    }

    sound.playClick();
    onStartQuiz(finalName, isAnonymous, selectedAvatarId);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-6 sm:py-10 animate-in fade-in duration-300">
      {/* Top Center Mascot & Header as seen in reference photo */}
      <div className="flex flex-col items-center text-center mb-7">
        {/* Cute Mascot Card at top */}
        <div className="relative mb-3">
          <div className="w-20 h-20 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-md p-2 flex items-center justify-center">
            <img
              src="/src/assets/images/messi_mascot_chibi_1792832639977.jpg"
              alt="Mascot Chibi"
              className="w-full h-full object-cover rounded-xl"
              referrerPolicy="no-referrer"
            />
          </div>
          <span className="absolute -bottom-1 -right-1 text-base select-none">
            ✨
          </span>
        </div>

        {/* Two Pill Badges */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-3">
          <div className="inline-flex items-center px-3.5 py-1 rounded-full text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 shadow-2xs">
            Quiz của Đỗ Thiện Nhân - Lớp 9A2
          </div>

          {/* Theme Dropdown Pill */}
          <div className="relative">
            <button
              type="button"
              onClick={() => {
                sound.playClick();
                setIsThemePickerOpen(!isThemePickerOpen);
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 shadow-2xs hover:bg-slate-50 transition-colors"
            >
              <span
                className="w-2.5 h-2.5 rounded-full"
                style={{ backgroundColor: theme.colorHex }}
              />
              <span>{theme.name}</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {isThemePickerOpen && (
              <div className="absolute left-1/2 transform -translate-x-1/2 mt-2 w-48 p-2 bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-700 z-50">
                {(Object.keys(THEMES) as ThemeColorKey[]).map(k => (
                  <button
                    key={k}
                    onClick={() => {
                      setThemeKey(k);
                      setIsThemePickerOpen(false);
                    }}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl text-xs font-medium ${
                      themeKey === k
                        ? 'bg-sky-50 dark:bg-slate-700 font-bold text-sky-600'
                        : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className="w-2.5 h-2.5 rounded-full"
                        style={{ backgroundColor: THEMES[k].colorHex }}
                      />
                      <span>{THEMES[k].name}</span>
                    </div>
                    {themeKey === k && <Check className="w-3.5 h-3.5" />}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Big Rounded Title & Sparkle */}
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white leading-tight">
          Bạn hiểu Đỗ Thiện Nhân (9A2) đến đâu?
        </h1>
        <div className="text-2xl mt-1 mb-2">✨</div>

        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 max-w-md">
          Chọn cách bạn muốn trả lời để thử độ hiểu nhau giữa hai bạn nhé!
        </p>

        {/* Nút Sao Chép Link & Mời Bạn Bè */}
        <div className="mt-3.5 flex flex-wrap items-center justify-center gap-2">
          <button
            type="button"
            onClick={handleCopyLink}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-bold transition-all shadow-2xs cursor-pointer ${
              copiedLink
                ? 'bg-emerald-600 text-white scale-105'
                : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 hover:border-slate-300'
            }`}
          >
            {copiedLink ? (
              <>
                <Check className="w-3.5 h-3.5 text-white" />
                <span>Đã sao chép link! Dán vào Messenger/Zalo gửi bạn bè nha 🎉</span>
              </>
            ) : (
              <>
                <Share2 className="w-3.5 h-3.5 text-pink-500" />
                <span>Sao Chép Link Gửi Bạn Bè 🔗</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main White Card as in screenshot */}
      <div className="bg-white dark:bg-slate-900 rounded-[32px] p-6 sm:p-8 shadow-xl border border-slate-100 dark:border-slate-800 space-y-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Section: Bạn muốn trả lời với tư cách nào? */}
          <div className="space-y-3">
            <div className="space-y-0.5">
              <h2 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-violet-500" />
                <span>Bạn muốn trả lời với tư cách nào?</span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Chọn một trong 2 cách bên dưới để bắt đầu làm bài:
              </p>
            </div>

            {/* 2 Big Choice Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-1">
              {/* Card 1: Ẩn danh */}
              <button
                type="button"
                onClick={() => handleModeSelect(true)}
                className={`flex flex-col justify-between p-4 rounded-2xl text-left transition-all duration-150 cursor-pointer ${
                  isAnonymous
                    ? 'border-2 border-emerald-500 bg-emerald-50/20 dark:bg-emerald-950/20 shadow-sm ring-1 ring-emerald-400/40'
                    : 'border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/40 hover:border-slate-300'
                }`}
              >
                <div>
                  <div className="text-2xl mb-1.5">🥷</div>
                  <div className="text-sm font-extrabold text-slate-900 dark:text-white">
                    Ẩn danh
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">
                    Che danh tính. Chỉ để lại manh mối/lời nhắn để bạn ấy đoán.
                  </div>
                </div>
                <div className="mt-3">
                  <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                    Bí mật & Hồi hộp
                  </span>
                </div>
              </button>

              {/* Card 2: Tên (Công khai) */}
              <button
                type="button"
                onClick={() => handleModeSelect(false)}
                className={`flex flex-col justify-between p-4 rounded-2xl text-left transition-all duration-150 cursor-pointer ${
                  !isAnonymous
                    ? 'border-2 border-emerald-500 bg-emerald-50/20 dark:bg-emerald-950/20 shadow-sm ring-1 ring-emerald-400/40'
                    : 'border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/40 hover:border-slate-300'
                }`}
              >
                <div>
                  <div className="text-2xl mb-1.5">🐻</div>
                  <div className="text-sm font-extrabold text-slate-900 dark:text-white">
                    Tên (Công khai)
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">
                    Hiện tên thật để bạn ấy biết chính xác ai làm bài.
                  </div>
                </div>
                <div className="mt-3">
                  <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500 text-white shadow-2xs">
                    Tự tin & Rõ ràng
                  </span>
                </div>
              </button>
            </div>
          </div>

          {/* Section: AVATAR CỦA BẠN */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 uppercase tracking-wider">
                <Sparkles className="w-3.5 h-3.5 text-violet-500" />
                <span>Avatar đại diện của bạn</span>
              </span>
              <span className="text-[11px] font-semibold px-2.5 py-0.5 rounded-full bg-violet-100 dark:bg-violet-950 text-violet-700 dark:text-violet-300">
                Chibi #{avatarNumber}
              </span>
            </div>

            {/* Avatar Preview Box with Edit & Random buttons */}
            <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                {/* Avatar with purple edit pencil badge */}
                <div className="relative">
                  <div className="w-14 h-14 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-3xl shadow-xs">
                    {selectedAvatar.emoji}
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      sound.playClick();
                      setIsAvatarModalOpen(true);
                    }}
                    className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-violet-600 text-white flex items-center justify-center shadow-xs hover:scale-110 transition-transform"
                    title="Đổi biểu cảm"
                  >
                    <Pencil className="w-2.5 h-2.5" />
                  </button>
                </div>

                <div>
                  <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                    {selectedAvatar.name} <span className="text-xs font-normal text-slate-400">/ {CUTE_AVATARS.length} mẫu</span>
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">
                    Chọn biểu cảm cute làm đại diện khi gửi kết quả
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    setIsAvatarModalOpen(true);
                  }}
                  className="px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-[11px] font-bold text-violet-600 dark:text-violet-400 hover:bg-violet-50 transition-colors shadow-2xs whitespace-nowrap"
                >
                  Chọn biểu cảm khác
                </button>

                <button
                  type="button"
                  onClick={handleRandomizeAvatar}
                  className="px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-[11px] font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 transition-colors shadow-2xs flex items-center gap-1 whitespace-nowrap"
                >
                  <Shuffle className="w-3 h-3 text-slate-400" />
                  <span>Đổi ngẫu nhiên</span>
                </button>
              </div>
            </div>
          </div>

          {/* Section: Nhập tên */}
          <div className="space-y-1.5">
            <label htmlFor="playerNameInput" className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              Nhập tên:
            </label>
            <input
              id="playerNameInput"
              type="text"
              maxLength={30}
              value={playerName}
              onChange={e => {
                setPlayerName(e.target.value);
                if (nameError) setNameError('');
              }}
              placeholder={isAnonymous ? 'Ví dụ: Bạn thân bí ẩn, Ẩn danh 9A2...' : 'Ví dụ: Đức Huy 9A2, Bạn thân sân bóng...'}
              className="w-full px-4 py-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/60 text-slate-900 dark:text-white placeholder-slate-400 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-2xs"
            />
            {nameError && (
              <p className="text-xs text-rose-500 font-medium animate-in fade-in">
                {nameError}
              </p>
            )}
          </div>

          {/* Big Action Button: Bắt Đầu Làm Bài 🚀 */}
          <button
            type="submit"
            className="w-full py-3.5 px-6 rounded-2xl text-base font-extrabold text-white shadow-md hover:shadow-lg transition-transform active:scale-98 flex items-center justify-center gap-2 bg-[#4338CA] hover:bg-[#3730A3]"
          >
            <span>Bắt Đầu Làm Bài</span>
            <Play className="w-4 h-4 fill-white" />
          </button>

          {/* Helper note at bottom as shown in screenshot */}
          <div className="text-center pt-1 text-[11px] text-slate-400 dark:text-slate-500 flex items-center justify-center gap-1.5">
            <Lightbulb className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>Làm bài không cần đăng ký tài khoản. Kết quả sẽ được lưu vào Dashboard!</span>
          </div>
        </form>
      </div>

      {/* Cute Avatar Picker Modal */}
      {isAvatarModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white dark:bg-slate-900 rounded-[28px] max-w-sm w-full p-5 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-violet-500" />
                <span>Chọn Biểu Cảm Chibi ({CUTE_AVATARS.length} mẫu)</span>
              </h3>
              <button
                onClick={() => setIsAvatarModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-4 gap-2.5">
              {CUTE_AVATARS.map((av, idx) => {
                const isSelected = selectedAvatarId === av.id;
                return (
                  <button
                    key={av.id}
                    type="button"
                    onClick={() => {
                      sound.playClick();
                      setSelectedAvatarId(av.id);
                      setIsAvatarModalOpen(false);
                    }}
                    className={`flex flex-col items-center justify-center p-3 rounded-2xl border transition-all ${
                      isSelected
                        ? 'border-2 border-violet-600 bg-violet-50 dark:bg-violet-950/40 scale-105 shadow-sm'
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50'
                    }`}
                  >
                    <span className="text-3xl mb-1">{av.emoji}</span>
                    <span className="text-[10px] font-bold text-slate-700 dark:text-slate-300 truncate w-full text-center">
                      #{idx + 1}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
