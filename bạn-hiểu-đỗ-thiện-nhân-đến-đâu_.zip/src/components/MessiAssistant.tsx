import React, { useState, useEffect } from 'react';
import { useTheme } from '../context/ThemeContext';
import { X, Sparkles } from 'lucide-react';
import { sound } from '../utils/sound';
import confetti from 'canvas-confetti';

interface MessiAssistantProps {
  currentMessage?: string;
  questionNumber?: number;
}

const DEFAULT_CHEERS = [
  'Haii bạn yêu! Hôm nay bạn hiểu bạn thân Đỗ Thiện Nhân đến đâu rồi? 🌸',
  'Messi mách nhỏ: Nhân thích ra sân bóng và uống nước lọc siêu lành mạnh nha! ⚽',
  'Ước mơ của Nhân là thành SIÊU ĐẸP TRAI, nhớ đừng chọn nhầm đấy nhé! ✨',
  'Roblox, Liên Quân, Free Fire hay Minecraft? Game thủ 9A2 đỉnh chóp! 🎮',
  'Cố lên bạn ơi! Làm xong là có tên trên Bảng Vàng Tri Kỷ liền! 🏆',
];

export const MessiAssistant: React.FC<MessiAssistantProps> = ({
  currentMessage,
  questionNumber,
}) => {
  const { theme } = useTheme();
  const [isOpen, setIsOpen] = useState(true);
  const [cheerIndex, setCheerIndex] = useState(0);

  const activeMessage = currentMessage || DEFAULT_CHEERS[cheerIndex % DEFAULT_CHEERS.length];

  // Rotate cheer messages every 15s if no custom message is set
  useEffect(() => {
    if (currentMessage) return;
    const interval = setInterval(() => {
      setCheerIndex(prev => prev + 1);
    }, 12000);
    return () => clearInterval(interval);
  }, [currentMessage]);

  const handleMascotClick = () => {
    sound.playClick();
    setCheerIndex(prev => prev + 1);
    if (!isOpen) {
      setIsOpen(true);
    }
    // Launch mini celebration confetti on mascot click as requested in tooltip
    try {
      confetti({
        particleCount: 30,
        spread: 60,
        origin: { x: 0.9, y: 0.85 },
      });
    } catch {
      // Ignore
    }
  };

  return (
    <aside aria-label="Trợ lý Messi" className="fixed bottom-3 right-3 z-30 flex flex-col items-end select-none">
      {/* Speech Bubble Card as seen in screenshot */}
      {isOpen && (
        <div className="relative mb-2 max-w-[280px] sm:max-w-xs bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 p-3 rounded-2xl shadow-xl border border-slate-200/90 dark:border-slate-800 animate-in fade-in slide-in-from-bottom-2 duration-200">
          <div className="flex items-center justify-between pb-1 border-b border-slate-100 dark:border-slate-800 mb-1.5">
            <span className="text-[11px] font-extrabold text-violet-600 dark:text-violet-400 uppercase tracking-wider flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-500" />
              MESSI CHÀO
            </span>
            <button
              onClick={() => setIsOpen(false)}
              className="p-0.5 rounded-md text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              title="Đóng lời nhắn"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <p className="text-xs font-semibold leading-relaxed text-slate-700 dark:text-slate-200">
            {activeMessage}
          </p>

          <div className="mt-2 text-[10px] text-violet-600 dark:text-violet-400 font-medium">
            👉 Bấm vào mình để đổi biểu cảm & pháo hoa!
          </div>

          {/* Bubble tail */}
          <div className="absolute -bottom-1.5 right-7 w-3 h-3 bg-white dark:bg-slate-900 border-b border-r border-slate-200 dark:border-slate-800 transform rotate-45" />
        </div>
      )}

      {/* Mascot Waving Button */}
      <div className="flex flex-col items-end">
        {/* Click me pill tag as seen in screenshot */}
        <div className="mr-3 mb-1 px-2 py-0.5 rounded-full text-[9px] font-extrabold bg-pink-500 text-white shadow-xs animate-bounce">
          Click me! ✨
        </div>

        <button
          onClick={handleMascotClick}
          className="group relative focus-visible:outline-none transition-transform hover:scale-105 active:scale-95"
          title="Bấm để tương tác cùng Messi!"
        >
          <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full overflow-hidden bg-white dark:bg-slate-800 border-2 border-white dark:border-slate-700 shadow-xl flex items-center justify-center">
            <img
              src="/src/assets/images/messi_mascot_chibi_1792832639977.jpg"
              alt="Mascot Messi 10"
              className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-300"
              referrerPolicy="no-referrer"
            />
          </div>
        </button>
      </div>
    </aside>
  );
};
