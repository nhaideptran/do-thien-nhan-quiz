import React, { useState, useEffect } from 'react';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { Header } from './components/Header';
import { StartScreen } from './components/StartScreen';
import { QuizScreen } from './components/QuizScreen';
import { ResultScreen } from './components/ResultScreen';
import { DashboardScreen } from './components/DashboardScreen';
import { MessiAssistant } from './components/MessiAssistant';
import { CreateQuizModal } from './components/CreateQuizModal';
import {
  QuizQuestion,
  QuizSubmission,
  ViewMode,
  AvatarOption,
} from './types';
import {
  DEFAULT_QUESTIONS,
  INITIAL_SEEDED_SUBMISSIONS,
  CUTE_AVATARS,
  getFeedbackForScore,
  shuffleQuizQuestions,
} from './data/quizData';
import { sound } from './utils/sound';

function QuizAppContent() {
  const { theme } = useTheme();

  // Navigation & Screen View
  const [currentView, setCurrentView] = useState<ViewMode>('start');

  // Questions state (persisted)
  const [questions, setQuestions] = useState<QuizQuestion[]>(() => {
    try {
      const saved = localStorage.getItem('thiennhan_quiz_questions');
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return DEFAULT_QUESTIONS;
  });

  // Submissions state (persisted)
  const [submissions, setSubmissions] = useState<QuizSubmission[]>(() => {
    try {
      const saved = localStorage.getItem('thiennhan_quiz_submissions');
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return INITIAL_SEEDED_SUBMISSIONS;
  });

  // Shuffled active questions for the current playthrough
  const [activeQuestions, setActiveQuestions] = useState<QuizQuestion[]>(() => {
    return shuffleQuizQuestions(DEFAULT_QUESTIONS);
  });

  // Active Player state
  const [activePlayerName, setActivePlayerName] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [selectedAvatarId, setSelectedAvatarId] = useState('gamer');

  // Latest Submission to display on Result Screen
  const [latestSubmission, setLatestSubmission] = useState<QuizSubmission | null>(null);

  // Messi Mascot message state
  const [messiMessage, setMessiMessage] = useState<string | undefined>(undefined);
  const [messiQuestionNum, setMessiQuestionNum] = useState<number | undefined>(undefined);

  // Create Quiz Modal state
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  // Sync state to localStorage
  useEffect(() => {
    localStorage.setItem('thiennhan_quiz_questions', JSON.stringify(questions));
  }, [questions]);

  useEffect(() => {
    localStorage.setItem('thiennhan_quiz_submissions', JSON.stringify(submissions));
  }, [submissions]);

  // Handler: Start quiz from StartScreen with freshly shuffled questions and options
  const handleStartQuiz = (playerName: string, anonymous: boolean, avatarId: string) => {
    // Luôn đảo ngẫu nhiên thứ tự câu hỏi và thứ tự các đáp án A B C D mỗi lần chơi mới
    const freshlyShuffled = shuffleQuizQuestions(questions);
    setActiveQuestions(freshlyShuffled);

    setActivePlayerName(playerName);
    setIsAnonymous(anonymous);
    setSelectedAvatarId(avatarId);
    setCurrentView('quiz');
    setMessiMessage(
      `Chào ${playerName}! Cùng bước vào câu số 1 xem độ ăn ý với Đỗ Thiện Nhân nhé!`
    );
    setMessiQuestionNum(1);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Handler: Complete quiz from QuizScreen
  const handleCompleteQuiz = (
    answers: Record<number, string>,
    timeSpentSeconds: number
  ) => {
    // Calculate score using activeQuestions (the shuffled set)
    let score = 0;
    activeQuestions.forEach(q => {
      if (answers[q.id] === q.correctOptionId) {
        score++;
      }
    });

    const percentage = Math.round((score / activeQuestions.length) * 100);
    const feedback = getFeedbackForScore(score, activeQuestions.length);

    const newSubmission: QuizSubmission = {
      id: 'sub-' + Date.now(),
      playerName: activePlayerName || (isAnonymous ? 'Người Bạn Bí Ẩn' : 'Bạn 9A2'),
      isAnonymous,
      avatarId: selectedAvatarId,
      score,
      totalQuestions: activeQuestions.length,
      percentage,
      answers,
      submittedAt: Date.now(),
      timeSpentSeconds,
      feedbackTier: feedback.tier,
      feedbackTitle: feedback.title,
      feedbackQuote: feedback.quote,
    };

    // Save to submissions
    setSubmissions(prev => [newSubmission, ...prev]);
    setLatestSubmission(newSubmission);
    setCurrentView('result');

    // Messi reaction
    setMessiMessage(feedback.messiReaction);
    setMessiQuestionNum(undefined);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Handler: Play again with fresh shuffle
  const handlePlayAgain = () => {
    sound.playClick();
    // Tạo bộ câu hỏi và đáp án đảo mới cho lần chơi tiếp theo
    const freshlyShuffled = shuffleQuizQuestions(questions);
    setActiveQuestions(freshlyShuffled);

    setCurrentView('start');
    setMessiMessage('Messi đã sẵn sàng! Cùng làm lại để đạt điểm tuyệt đối 10/10 nào!');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Handler: Add custom question
  const handleAddCustomQuestion = (newQ: QuizQuestion) => {
    setQuestions(prev => [...prev, newQ]);
  };

  // Handler: Reset submissions
  const handleResetData = () => {
    sound.playClick();
    setSubmissions(INITIAL_SEEDED_SUBMISSIONS);
    setQuestions(DEFAULT_QUESTIONS);
    localStorage.removeItem('thiennhan_quiz_submissions');
    localStorage.removeItem('thiennhan_quiz_questions');
    setMessiMessage('Bảng điểm đã được khôi phục về trạng thái ban đầu của lớp 9A2!');
  };

  const currentAvatar =
    CUTE_AVATARS.find(a => a.id === selectedAvatarId) || CUTE_AVATARS[0];

  return (
    <div className="min-h-screen flex flex-col bg-[#EFF6F8] dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-200 font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Top Bar Header */}
      <Header
        currentView={currentView}
        onNavigate={view => {
          setCurrentView(view);
          if (view === 'start') {
            setMessiMessage('Haii bạn yêu! Hôm nay bạn hiểu bạn thân Đỗ Thiện Nhân đến đâu rồi? 🌸');
            setMessiQuestionNum(undefined);
          } else if (view === 'dashboard') {
            setMessiMessage('Đây là bảng vinh danh những người bạn hiểu Đỗ Thiện Nhân nhất!');
            setMessiQuestionNum(undefined);
          }
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenCreateModal={() => setIsCreateModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 pb-24">
        {currentView === 'start' && (
          <StartScreen
            onStartQuiz={handleStartQuiz}
            onViewDashboard={() => {
              setCurrentView('dashboard');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onOpenCreateModal={() => setIsCreateModalOpen(true)}
            totalSubmissionsCount={submissions.length}
          />
        )}

        {currentView === 'quiz' && (
          <QuizScreen
            questions={activeQuestions}
            playerName={activePlayerName || (isAnonymous ? 'Người Bạn Bí Ẩn' : 'Bạn 9A2')}
            isAnonymous={isAnonymous}
            avatar={currentAvatar}
            onCompleteQuiz={handleCompleteQuiz}
            onSetMessiMessage={(msg, qNum) => {
              setMessiMessage(msg);
              setMessiQuestionNum(qNum);
            }}
            onCancelQuiz={() => {
              setCurrentView('start');
              setMessiMessage('Messi chào bạn! Khi nào rảnh quay lại làm tiếp nhé!');
              setMessiQuestionNum(undefined);
            }}
          />
        )}

        {currentView === 'result' && latestSubmission && (
          <ResultScreen
            submission={latestSubmission}
            questions={activeQuestions}
            onPlayAgain={handlePlayAgain}
            onViewDashboard={() => {
              setCurrentView('dashboard');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {currentView === 'dashboard' && (
          <DashboardScreen
            submissions={submissions}
            questions={questions}
            onStartQuiz={() => {
              setCurrentView('start');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onResetData={handleResetData}
            onOpenCreateModal={() => setIsCreateModalOpen(true)}
          />
        )}
      </main>

      {/* Messi Assistant Floating Mascot */}
      <MessiAssistant
        currentMessage={messiMessage}
        questionNumber={messiQuestionNum}
      />

      {/* Create / Expand Quiz Modal */}
      <CreateQuizModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onAddCustomQuestion={handleAddCustomQuestion}
        totalQuestions={questions.length}
      />

      {/* Clean Quiet Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 py-6 text-center text-xs text-slate-500 dark:text-slate-400">
        <div className="max-w-4xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-700 dark:text-slate-300">
              Bạn hiểu Đỗ Thiện Nhân đến đâu?
            </span>
            <span aria-hidden="true">·</span>
            <span>Khối THCS 9A2</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => {
                sound.playClick();
                setCurrentView('start');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="hover:text-slate-900 dark:hover:text-white transition-colors"
            >
              Trang Chủ
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setCurrentView('dashboard');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="hover:text-slate-900 dark:hover:text-white transition-colors"
            >
              Bảng Xếp Hạng
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setIsCreateModalOpen(true);
              }}
              className="hover:text-slate-900 dark:hover:text-white transition-colors"
            >
              + Tạo Quiz
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <QuizAppContent />
    </ThemeProvider>
  );
}
