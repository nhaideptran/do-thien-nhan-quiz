import { QuizQuestion, AvatarOption, ThemeConfig, ThemeColorKey, QuizSubmission } from '../types';

export const THEMES: Record<ThemeColorKey, ThemeConfig> = {
  blue: {
    id: 'blue',
    name: 'Màu Xanh Dương',
    colorHex: '#0ea5e9',
    badgeBg: 'bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300',
    gradientFrom: 'from-sky-500',
    gradientTo: 'to-blue-600',
    primaryBg: 'bg-sky-600',
    primaryHover: 'hover:bg-sky-700',
    primaryText: 'text-sky-600 dark:text-sky-400',
    borderActive: 'border-sky-500',
    ringColor: 'ring-sky-400',
    accentBg: 'bg-sky-50/70 dark:bg-sky-950/40',
  },
  pink: {
    id: 'pink',
    name: 'Màu Hồng Dễ Thương',
    colorHex: '#ec4899',
    badgeBg: 'bg-pink-100 text-pink-800 dark:bg-pink-950 dark:text-pink-300',
    gradientFrom: 'from-pink-500',
    gradientTo: 'to-rose-600',
    primaryBg: 'bg-pink-600',
    primaryHover: 'hover:bg-pink-700',
    primaryText: 'text-pink-600 dark:text-pink-400',
    borderActive: 'border-pink-500',
    ringColor: 'ring-pink-400',
    accentBg: 'bg-pink-50/70 dark:bg-pink-950/40',
  },
  purple: {
    id: 'purple',
    name: 'Màu Tím Mộng Mơ',
    colorHex: '#8b5cf6',
    badgeBg: 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300',
    gradientFrom: 'from-purple-500',
    gradientTo: 'to-indigo-600',
    primaryBg: 'bg-purple-600',
    primaryHover: 'hover:bg-purple-700',
    primaryText: 'text-purple-600 dark:text-purple-400',
    borderActive: 'border-purple-500',
    ringColor: 'ring-purple-400',
    accentBg: 'bg-purple-50/70 dark:bg-purple-950/40',
  },
  emerald: {
    id: 'emerald',
    name: 'Màu Xanh Mint Tươi Mới',
    colorHex: '#10b981',
    badgeBg: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300',
    gradientFrom: 'from-emerald-500',
    gradientTo: 'to-teal-600',
    primaryBg: 'bg-emerald-600',
    primaryHover: 'hover:bg-emerald-700',
    primaryText: 'text-emerald-600 dark:text-emerald-400',
    borderActive: 'border-emerald-500',
    ringColor: 'ring-emerald-400',
    accentBg: 'bg-emerald-50/70 dark:bg-emerald-950/40',
  },
  amber: {
    id: 'amber',
    name: 'Màu Cam Rực Rỡ',
    colorHex: '#f59e0b',
    badgeBg: 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300',
    gradientFrom: 'from-amber-500',
    gradientTo: 'to-orange-600',
    primaryBg: 'bg-amber-500',
    primaryHover: 'hover:bg-amber-600',
    primaryText: 'text-amber-600 dark:text-amber-400',
    borderActive: 'border-amber-500',
    ringColor: 'ring-amber-400',
    accentBg: 'bg-amber-50/70 dark:bg-amber-950/40',
  },
};

/**
 * Đảo ngẫu nhiên thứ tự câu hỏi và thứ tự các đáp án A, B, C, D
 * Đảm bảo đáp án đúng KHÔNG cố định ở A mà được phân bổ ngẫu nhiên A, B, C, D mỗi lần chơi!
 */
export function shuffleQuizQuestions(questions: QuizQuestion[]): QuizQuestion[] {
  // 1. Trộn ngẫu nhiên danh sách câu hỏi
  const shuffledQuestions = [...questions].sort(() => Math.random() - 0.5);

  // 2. Trộn ngẫu nhiên 4 lựa chọn của mỗi câu hỏi và gán lại ID: A, B, C, D
  return shuffledQuestions.map((q, qIndex) => {
    // Xác định nội dung đáp án đúng gốc
    const originalCorrectOption = q.options.find(opt => opt.id === q.correctOptionId);
    const correctText = originalCorrectOption ? originalCorrectOption.text : q.options[0].text;

    // Trộn ngẫu nhiên các lựa chọn
    const shuffledRawOptions = [...q.options].sort(() => Math.random() - 0.5);
    const letters = ['A', 'B', 'C', 'D'];

    let newCorrectLetter = 'A';
    const newOptions = shuffledRawOptions.map((opt, optIndex) => {
      const letter = letters[optIndex];
      if (opt.text === correctText) {
        newCorrectLetter = letter;
      }
      return {
        id: letter,
        text: opt.text,
      };
    });

    return {
      ...q,
      id: qIndex + 1, // Thứ tự câu hiển thị 1, 2, 3...
      options: newOptions,
      correctOptionId: newCorrectLetter,
    };
  });
}

export const CUTE_AVATARS: AvatarOption[] = [
  { id: 'cool', emoji: '🕶️', name: 'Siêu Ngầu', badge: 'Chuyên gia phá đảo', bgColor: 'bg-blue-100 dark:bg-blue-900/40' },
  { id: 'gamer', emoji: '🎮', name: 'Chiến Thần Game', badge: 'Gánh team 9A2', bgColor: 'bg-purple-100 dark:bg-purple-900/40' },
  { id: 'soccer', emoji: '⚽', name: 'Vua Sân Cỏ', badge: 'Hậu duệ Messi', bgColor: 'bg-emerald-100 dark:bg-emerald-900/40' },
  { id: 'study', emoji: '💻', name: 'Trùm Tin Học', badge: 'Bậc thầy công nghệ', bgColor: 'bg-indigo-100 dark:bg-indigo-900/40' },
  { id: 'cute', emoji: '✨', name: 'Bé Đáng Yêu', badge: 'Dễ thương vô đối', bgColor: 'bg-pink-100 dark:bg-pink-900/40' },
  { id: 'ninja', emoji: '🥷', name: 'Ẩn Sĩ Bí Ẩn', badge: 'Cao thủ giấu mặt', bgColor: 'bg-slate-100 dark:bg-slate-800' },
  { id: 'star', emoji: '⭐', name: 'Siêu Sao 9A2', badge: 'Tỏa sáng rực rỡ', bgColor: 'bg-amber-100 dark:bg-amber-900/40' },
  { id: 'cat', emoji: '🐱', name: 'Mèo Thức Đêm', badge: 'Chuyên gia cày game', bgColor: 'bg-rose-100 dark:bg-rose-900/40' },
];

export const DEFAULT_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: 'Chủ nhân của bộ câu hỏi trắc nghiệm này là ai vậy bạn ơi?',
    subtitle: 'Khởi động câu đầu tiên cực dễ, không thể sai được nha!',
    tag: 'Thông tin cá nhân',
    iconName: 'User',
    options: [
      { id: 'A', text: 'Đỗ Thiện Nhân' },
      { id: 'B', text: 'Nguyễn Thiện Nhân' },
      { id: 'C', text: 'Đỗ Trọng Nhân' },
      { id: 'D', text: 'Đỗ Minh Nhân' },
    ],
    correctOptionId: 'A',
    explanation: 'Chính xác! Chủ nhân quiz chính là bạn Đỗ Thiện Nhân siêu đẹp trai và vui tính.',
    messiComment: 'Messi vừa nhìn tên Đỗ Thiện Nhân là biết ngay người uy tín rồi!',
  },
  {
    id: 2,
    question: 'Hiện tại, Thiện Nhân đang là học sinh của lớp nào khối THCS?',
    subtitle: 'Cùng trường cùng khối thì câu này trả lời trong một nốt nhạc!',
    tag: 'Trường lớp',
    iconName: 'GraduationCap',
    options: [
      { id: 'A', text: 'Lớp 9A1' },
      { id: 'B', text: 'Lớp 9A2' },
      { id: 'C', text: 'Lớp 8A2' },
      { id: 'D', text: 'Lớp 10A2' },
    ],
    correctOptionId: 'B',
    explanation: 'Chuẩn luôn! Nhân là một thành viên ưu tú và vui tính của tập thể lớp 9A2.',
    messiComment: '9A2 hội tụ toàn anh tài, Thiện Nhân là linh hồn của các cuộc vui!',
  },
  {
    id: 3,
    question: 'Môn học nào được Thiện Nhân yêu thích nhất mỗi khi đến trường?',
    subtitle: 'Một môn học đòi hỏi tư duy logic và máy móc siêu thú vị!',
    tag: 'Học tập',
    iconName: 'Laptop',
    options: [
      { id: 'A', text: 'Tin học' },
      { id: 'B', text: 'Thể dục' },
      { id: 'C', text: 'Toán học' },
      { id: 'D', text: 'Ngữ văn' },
    ],
    correctOptionId: 'A',
    explanation: 'Tin học chính là môn học chân ái của Thiện Nhân! Vừa thích máy tính vừa mê khám phá công nghệ.',
    messiComment: 'Gõ bàn phím thoăn thoắt, sau này làm siêu lập trình viên luôn!',
  },
  {
    id: 4,
    question: 'Sở thích giải trí số 1 của Thiện Nhân trong những lúc rảnh rỗi là gì?',
    subtitle: 'Hoạt động gắn kết tinh thần đồng đội cực mạnh!',
    tag: 'Giải trí',
    iconName: 'Gamepad2',
    options: [
      { id: 'A', text: 'Chơi game cùng bạn bè' },
      { id: 'B', text: 'Đọc sách cả ngày trong phòng' },
      { id: 'C', text: 'Đi câu cá một mình' },
      { id: 'D', text: 'Ngủ nướng từ sáng đến tối' },
    ],
    correctOptionId: 'A',
    explanation: 'Có bạn có bè quẩy game mới vui! Thiện Nhân thích nhất là cùng anh em chiến game rộn rã tiếng cười.',
    messiComment: 'Có đồng đội kề vai sát cánh thì dù leo rank hay quẩy game đều bất bại!',
  },
  {
    id: 5,
    question: 'Đâu là bộ tứ tựa game yêu thích mà Thiện Nhân thường xuyên cày cuốc?',
    subtitle: 'Các tựa game huyền thoại mà anh em game thủ đều biết đến!',
    tag: 'Gaming',
    iconName: 'Flame',
    options: [
      { id: 'A', text: 'Roblox, Liên Quân Mobile, Free Fire, Minecraft' },
      { id: 'B', text: 'FIFA Online 4, PUBG, Valorant, GTA V' },
      { id: 'C', text: 'Genshin Impact, Honkai Star Rail, LOL, CS:GO' },
      { id: 'D', text: 'Candy Crush, Subway Surfers, Nông Trại Vui Vẻ, Cờ Tỷ Phú' },
    ],
    correctOptionId: 'A',
    explanation: 'Bộ tứ huyền thoại: Roblox thỏa sức sáng tạo, Liên Quân leo rank thần tốc, Free Fire giật Booyah và Minecraft xây dựng thế giới!',
    messiComment: 'Cả 4 game đều là game tủ của giới trẻ, anh em vào lập team kéo rank liền!',
  },
  {
    id: 6,
    question: 'Thức uống yêu thích hàng ngày của Thiện Nhân là gì?',
    subtitle: 'Thanh lọc cơ thể, giản dị nhưng siêu tốt cho sức khỏe!',
    tag: 'Thói quen',
    iconName: 'Droplets',
    options: [
      { id: 'A', text: 'Nước lọc' },
      { id: 'B', text: 'Trà sữa trân châu đường đen' },
      { id: 'C', text: 'Nước ngọt có ga' },
      { id: 'D', text: 'Cà phê đá đậm đặc' },
    ],
    correctOptionId: 'A',
    explanation: 'Nước lọc thanh khiết là lựa chọn hàng đầu! Vừa tiết kiệm lại tràn đầy năng lượng lành mạnh.',
    messiComment: 'Uống nước lọc là bí quyết giữ thể lực dồi dào của các siêu sao thể thao như Messi đó!',
  },
  {
    id: 7,
    question: 'Địa điểm quen thuộc mà Thiện Nhân thường đến nhất khi có thời gian rảnh?',
    subtitle: 'Nơi đốt cháy năng lượng và thể hiện đam mê thể thao!',
    tag: 'Địa điểm yêu thích',
    iconName: 'MapPin',
    options: [
      { id: 'A', text: 'Sân bóng' },
      { id: 'B', text: 'Thư viện trường' },
      { id: 'C', text: 'Quán trà sữa ven đường' },
      { id: 'D', text: 'Trung tâm mua sắm sầm uất' },
    ],
    correctOptionId: 'A',
    explanation: 'Sân bóng chính là thánh địa quen thuộc! Chạy nhảy, rê bóng cùng anh em bạn bè là vui nhất.',
    messiComment: 'Đến sân bóng là cùng hệ với Messi rồi! Cho Messi mượn quả bóng làm đường chuyền kiến tạo nhé!',
  },
  {
    id: 8,
    question: 'Thiện Nhân tự nhận xét về tính cách của bản thân như thế nào?',
    subtitle: 'Một phong cách sống rất tích cực và dễ mến!',
    tag: 'Tính cách',
    iconName: 'Smile',
    options: [
      { id: 'A', text: 'Vui tính, thích kết bạn với người hợp cạ và chung sở thích' },
      { id: 'B', text: 'Lạnh lùng, ít nói và xa cách với mọi người' },
      { id: 'C', text: 'Nghiêm khắc, khó tính và ghét những chỗ ồn ào' },
      { id: 'D', text: 'Nhút nhát, không thích tiếp xúc hay kết bạn mới' },
    ],
    correctOptionId: 'A',
    explanation: 'Thiện Nhân rất vui tính, cởi mở và luôn hào hứng kết thân với những bạn có chung niềm vui, chung sở thích!',
    messiComment: 'Tính cách này thì đi đâu cũng có bạn tốt bao quanh, tuyệt vời!',
  },
  {
    id: 9,
    question: 'Mỗi khi gặp chuyện áp lực hay buồn phiền, Thiện Nhân thường chia sẻ cùng ai?',
    subtitle: 'Nơi bình yên và ấm áp nhất đối với mỗi chúng ta.',
    tag: 'Tâm sự',
    iconName: 'HeartHandshake',
    options: [
      { id: 'A', text: 'Bố mẹ' },
      { id: 'B', text: 'Người lạ trên mạng xã hội' },
      { id: 'C', text: 'Im lặng và viết vào nhật ký bí mật' },
      { id: 'D', text: 'Trợ lý ảo máy tính' },
    ],
    correctOptionId: 'A',
    explanation: 'Bố mẹ luôn là điểm tựa vững chãi và đáng tin cậy nhất để Nhân sẻ chia mọi tâm tư buồn vui!',
    messiComment: 'Một người con hiếu thảo và biết trân trọng gia đình. 10 điểm tuyệt đối cho Thiện Nhân!',
  },
  {
    id: 10,
    question: 'Mục tiêu vui và ước mơ to lớn của Thiện Nhân là gì?',
    subtitle: 'Một mục tiêu vừa hài hước vừa tràn đầy sự tự tin!',
    tag: 'Ước mơ',
    iconName: 'Sparkles',
    options: [
      { id: 'A', text: 'Trở thành "SIÊU ĐẸP TRAI"' },
      { id: 'B', text: 'Trở thành tỷ phú công nghệ' },
      { id: 'C', text: 'Lên phi thuyền bay đến sao Hỏa' },
      { id: 'D', text: 'Vô địch giải đấu game thế giới' },
    ],
    correctOptionId: 'A',
    explanation: 'Chính là trở thành "SIÊU ĐẸP TRAI"! Ước mơ chân thực, tự tin và khiến ai nghe cũng bật cười thích thú.',
    messiComment: 'Haha mục tiêu này Messi chuẩn y! Vừa đá bóng giỏi vừa đẹp trai thì ai mà không mê!',
  },
];

export const INITIAL_SEEDED_SUBMISSIONS: QuizSubmission[] = [
  {
    id: 'seed-1',
    playerName: 'Đức Huy 9A2',
    isAnonymous: false,
    avatarId: 'gamer',
    score: 10,
    totalQuestions: 10,
    percentage: 100,
    answers: { 1: 'A', 2: 'B', 3: 'A', 4: 'A', 5: 'A', 6: 'A', 7: 'A', 8: 'A', 9: 'A', 10: 'A' },
    submittedAt: Date.now() - 1000 * 60 * 35,
    timeSpentSeconds: 68,
    feedbackTier: 'soulmate',
    feedbackTitle: 'Tri Kỷ Đích Thực 🏆',
    feedbackQuote: 'Hiểu nhau đến từng chân tơ kẽ tóc, đúng là anh em chí cốt 9A2!',
  },
  {
    id: 'seed-2',
    playerName: 'Hải Nam (Chiến hữu sân bóng)',
    isAnonymous: false,
    avatarId: 'soccer',
    score: 9,
    totalQuestions: 10,
    percentage: 90,
    answers: { 1: 'A', 2: 'B', 3: 'A', 4: 'A', 5: 'A', 6: 'A', 7: 'A', 8: 'A', 9: 'A', 10: 'B' },
    submittedAt: Date.now() - 1000 * 60 * 120,
    timeSpentSeconds: 74,
    feedbackTier: 'soulmate',
    feedbackTitle: 'Tri Kỷ Đích Thực 🏆',
    feedbackQuote: 'Chỉ lệch xíu câu ước mơ, còn lại chuyện gì của Nhân cũng tường tận!',
  },
  {
    id: 'seed-3',
    playerName: 'Bạn Cùng Bàn Bí Ẩn',
    isAnonymous: true,
    avatarId: 'cool',
    score: 8,
    totalQuestions: 10,
    percentage: 80,
    answers: { 1: 'A', 2: 'B', 3: 'A', 4: 'A', 5: 'A', 6: 'B', 7: 'A', 8: 'A', 9: 'A', 10: 'A' },
    submittedAt: Date.now() - 1000 * 60 * 240,
    timeSpentSeconds: 92,
    feedbackTier: 'close_friend',
    feedbackTitle: 'Bạn Thân Hợp Cạ 🤝',
    feedbackQuote: 'Rất hiểu tính Nhân, cuối tuần rủ đi đá bóng hoặc chơi game là đúng bài!',
  },
  {
    id: 'seed-4',
    playerName: 'Linh (Lớp phó học tập)',
    isAnonymous: false,
    avatarId: 'study',
    score: 7,
    totalQuestions: 10,
    percentage: 70,
    answers: { 1: 'A', 2: 'B', 3: 'A', 4: 'B', 5: 'A', 6: 'A', 7: 'A', 8: 'A', 9: 'C', 10: 'A' },
    submittedAt: Date.now() - 1000 * 60 * 480,
    timeSpentSeconds: 85,
    feedbackTier: 'close_friend',
    feedbackTitle: 'Bạn Thân Hợp Cạ 🤝',
    feedbackQuote: 'Khá hiểu bạn mình rồi đấy, nhớ rủ Nhân chơi game nhiều hơn nha!',
  },
];

export function getFeedbackForScore(score: number, total: number) {
  const ratio = score / total;
  if (ratio >= 0.9) {
    return {
      tier: 'soulmate' as const,
      title: 'Tri Kỷ Đích Thực 🏆',
      badge: 'Cấp độ 100% Chí Cốt',
      quote: 'Bạn chắc chắn là anh em ruột thịt hoặc đồng đội chí cốt số 1 của Đỗ Thiện Nhân! Không gì về Nhân mà bạn không biết!',
      messiReaction: 'Messi phải ngả mũ bái phục bạn! Hiểu Nhân còn rõ hơn trọng tài biết luật việt vị!',
      confetti: true,
    };
  } else if (ratio >= 0.7) {
    return {
      tier: 'close_friend' as const,
      title: 'Bạn Thân Hợp Cạ 🤝',
      badge: 'Cấp độ Bạn Thân 9A2',
      quote: 'Bạn rất hiểu Thiện Nhân! Hai người chắc chắn thường xuyên cày game hoặc ra sân bóng quẩy cùng nhau!',
      messiReaction: 'Thành tích rất ấn tượng! Rủ Nhân đi làm một trận bóng rồi bao ly nước lọc là lên 10 điểm ngay!',
      confetti: true,
    };
  } else if (ratio >= 0.4) {
    return {
      tier: 'casual_friend' as const,
      title: 'Bạn Bè Thân Thiện 👋',
      badge: 'Cấp độ Bạn Cùng Lớp',
      quote: 'Bạn biết khá nhiều về Nhân nhưng vẫn còn vài bí mật nhỏ chưa khám phá hết. Hãy rủ Nhân chơi Roblox hay Liên Quân để thêm thân nhé!',
      messiReaction: 'Không sao đâu nè! Tình bạn cần thời gian, rủ Nhân vào tổ đội game là thân thiết ngay!',
      confetti: false,
    };
  } else {
    return {
      tier: 'stranger' as const,
      title: 'Người Lạ Dễ Thương 👀',
      badge: 'Cấp độ Khám Phá Mới',
      quote: 'Có vẻ bạn mới làm quen với Đỗ Thiện Nhân hoặc hôm nay đi nhầm vào lớp 9A2 rồi! Mau qua bắt chuyện với chàng trai vui tính này nhé!',
      messiReaction: 'Hiệp 1 chưa may mắn thì ta đá tiếp hiệp phụ! Bấm làm lại để trở thành tri kỷ của Nhân nào!',
      confetti: false,
    };
  }
}
