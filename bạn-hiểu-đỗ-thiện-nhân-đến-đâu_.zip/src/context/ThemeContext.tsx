import React, { createContext, useContext, useEffect, useState } from 'react';
import { ThemeColorKey, ThemeConfig } from '../types';
import { THEMES } from '../data/quizData';
import { sound } from '../utils/sound';

interface ThemeContextType {
  themeKey: ThemeColorKey;
  setThemeKey: (key: ThemeColorKey) => void;
  theme: ThemeConfig;
  isDark: boolean;
  toggleDarkMode: () => void;
  isMuted: boolean;
  toggleMute: () => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [themeKey, setThemeKeyState] = useState<ThemeColorKey>(() => {
    const saved = localStorage.getItem('thiennhan_quiz_theme') as ThemeColorKey;
    return saved && THEMES[saved] ? saved : 'blue';
  });

  const [isDark, setIsDark] = useState<boolean>(() => {
    const saved = localStorage.getItem('thiennhan_quiz_dark');
    if (saved !== null) return saved === 'true';
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  const [isMuted, setIsMuted] = useState<boolean>(() => {
    return localStorage.getItem('thiennhan_quiz_muted') === 'true';
  });

  useEffect(() => {
    localStorage.setItem('thiennhan_quiz_theme', themeKey);
  }, [themeKey]);

  useEffect(() => {
    localStorage.setItem('thiennhan_quiz_dark', String(isDark));
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  useEffect(() => {
    localStorage.setItem('thiennhan_quiz_muted', String(isMuted));
    sound.setMuted(isMuted);
  }, [isMuted]);

  const setThemeKey = (key: ThemeColorKey) => {
    sound.playClick();
    setThemeKeyState(key);
  };

  const toggleDarkMode = () => {
    sound.playClick();
    setIsDark(prev => !prev);
  };

  const toggleMute = () => {
    setIsMuted(prev => !prev);
  };

  return (
    <ThemeContext.Provider
      value={{
        themeKey,
        setThemeKey,
        theme: THEMES[themeKey],
        isDark,
        toggleDarkMode,
        isMuted,
        toggleMute,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
